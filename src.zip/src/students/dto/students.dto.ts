
export class StudentDTO{


    studentName:string;


    studentId:string;


    studentBranch:string;
}