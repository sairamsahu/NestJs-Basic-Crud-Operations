export class SalesDTO{
    ID:number;
    salesName:string;
    salesCode: string;
    quantity:number;
    price:number;
}